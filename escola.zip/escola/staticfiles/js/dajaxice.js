function calculate(){
    Dajaxice.SICOP.web.multiplicar(Dajax.process,{'a':$('#a').val(),'b':$('#b').val()})
}